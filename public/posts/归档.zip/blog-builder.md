---
title: 搭建免费博客网站
date: 2020-07-10 21:51:58
tags: "搭建博客"
categories: "tools"
cover: "https://cdn.jsdelivr.net/gh/jerryc127/CDN/img/hexo-theme-butterfly-doc-cover.jpg"
sticky: 10000
---

<p align="right">折叠播放列表 ≡ ⬇️</p>


{% meting "7652784085" "tencent" "playlist" "autoplay" "mutex:false" "listmaxheight:200px" "preload:none" "theme:#ad7a86" "loop:all" "order:random" %}

{% blockquote %}

我用虚拟机里面的`Win10`演示

{% endblockquote %}

# 准备环境

1. `GitHub`账号[注册地址](https://github.com/)
2. `Git`[下载地址](https://github.com/git-for-windows/git/releases/download/v2.27.0.windows.1/Git-2.27.0-64-bit.exe)
3. 下载`NodeJs`[下载地址](https://npm.taobao.org/mirrors/node/v14.5.0/node-v14.5.0-x64.msi)
4. 下个`Visual Studio Code`来编辑文件[下载地址](https://go.microsoft.com/fwlink/?Linkid=852157)（这个是为了让你更好得编辑`yml`文件，防止格式不正确，如果你有其他的，可以用其他的编辑器）

{% blockquote %}

上面的 3 个应用可以直接下载，等会再安装

{% endblockquote %}

## 注册Github账号 

如果你有`github`账号，直接从第六步开始

{% tabs content-1 %}

<!-- tab 第一步 -->

{% blockquote %}

输入账号/邮箱/密码。账号必须唯一

{% endblockquote %}

![进Github网站.png](https://i.loli.net/2020/07/10/rBsedoCKzcDTiZ1.png)

<!-- endtab -->

<!-- tab 第二步 -->

{% blockquote %}

这一步是验证你是不是人机，图像没出来的话，请等一等，或者刷新一下。

{% endblockquote %}

![验证.png](https://i.loli.net/2020/07/10/2mSGPx5e6zupgvI.png)



<!-- endtab -->

<!-- tab 第三步 -->

{% blockquote %}

不用管往下拉` Complete SignUp`

{% endblockquote %}

![往下拉.png](https://i.loli.net/2020/07/10/HgpeDkVqOcREJza.png)

<!-- endtab -->

<!-- tab 第四步 -->

{% blockquote %}

到这里验证一下邮箱。你可以登陆你刚才注册用的邮箱，看下邮件，点击邮件里面的验证` Verify Email`。

{% endblockquote %}

![邮箱验证.png](https://i.loli.net/2020/07/10/lFimT16bKGWqoyL.png)

<!-- endtab -->

<!-- tab 第五步 -->

{% blockquote %}

`Create a repository`

{% endblockquote %}

![创建库.png](https://i.loli.net/2020/07/10/wObKJgHhd89vmiq.png)

<!-- endtab -->

<!-- tab 第六步 -->

{% blockquote %}

你的用户名叫什么，就` [用户名].github.io` 	一定要叫这个名字。像下面这样，还有记得点初始化一个`README`文件。`很重要！！！！`

{% endblockquote %}

![给你的库取名字.png](https://i.loli.net/2020/07/10/EzSGVjIuCkp3L4U.png)

<!-- endtab -->

<!-- tab 第七步 -->

{% blockquote %}

创建好后就是下面这种情况

{% endblockquote %}

![sign-up-github-8.png](https://i.loli.net/2020/07/10/98R4pPeDmfnwQTy.png)

<!-- endtab -->

<!-- tab 第八步 -->

{% blockquote %}

访问一下看行不行，正常情况都能访问。（如果你是之前创建的`Github`账号是要去`settings`里面设置配置`pages`，现在创建了这个名字的`Repository`资料库就行了）。

{% endblockquote %}

![完成github方面内容.png](https://i.loli.net/2020/07/10/tvfePlZQxGFwsKE.png)

<!-- endtab -->

{% endtabs %}



## 安装Git

{% blockquote %}

双击安装包，一直点`next`，要注意勾选`Additional icons`就行。安装好后，桌面有个左上角的图标的快捷方式，就算安装成功了。

{% endblockquote %}

![git-install.png](https://i.loli.net/2020/07/11/1kCMnq6A5mu7Rhw.png)

## 下载NodeJs

{% tabs content-2 %}

<!-- tab 第一步 -->

{% blockquote %}

下载好后双击安装的`NodeJs.msi`文件，一直点击`next，accept`，`next`直到完成。

{% endblockquote %}

![nodejs-1.png](https://i.loli.net/2020/07/11/q9BPbgxu4KvdzEy.png)

<!-- endtab -->

<!-- tab 第二步 -->

{% blockquote %}

安装完成后，按`win+R`键，输入`cmd`。再输入`node -v`或者`npm -v`，如果有版本号输出，那就是安装好了。

{% endblockquote %}

![nodejs-2.png](https://i.loli.net/2020/07/11/8VXolPkHaDpQnyG.png)

<!-- endtab -->

{% endtabs %}

## VsCode安装

{% blockquote %}

一直点下一步就行了，记得点一个创建桌面快捷方式。安装好后有个快捷方式

{% endblockquote %}

![icons.png](https://i.loli.net/2020/07/11/V1vrnFZlN6Lb5BO.png)

# 安装

## 必须执行的操作

{% tabs content-3 %}

<!-- tab 第一步 -->

{% blockquote %}

输入并执行以下命令，一条一条复制粘贴按回车。

{% endblockquote %}

``` shell
npm config set registry https://registry.npm.taobao.org

npm config get registry

npm install -g hexo-cli

cd Desktop

mkdir blog

cd blog

hexo init

npm install

hexo g

hexo s
```

![operation-1.png](https://i.loli.net/2020/07/11/U3dpLYVxeS8iHQ1.png)

<!-- endtab -->

<!-- tab 第二步 -->

{% blockquote %}

在浏览器中输入`localhost:4000`会看到以下页面

{% endblockquote %}

![operation-2.png](https://i.loli.net/2020/07/11/ucrFiQ4l35XKYbv.png)

<!-- endtab -->

<!-- tab 第三步 -->

{% blockquote %}

返回之前的命令行窗口，按`ctrl+c`输入`Y`。确定你在 `Desktop/blog/`文件夹下时，输入以下命令。

{% endblockquote %}

``` shell
git clone -b master https://github.com/jerryc127/hexo-theme-butterfly.git themes/butterfly

npm install hexo-renderer-pug hexo-renderer-stylus --save

cd ..

git clone https://github.com/young1lin/hexo-butterfly-auxiliary-folder.git

cd ../blog
```

![operation-3.png](https://i.loli.net/2020/07/11/LGCEztQYFDI2r6w.png)

<!-- endtab -->

<!-- tab 第四步 -->

{% blockquote %}

将下面的`/hexo-butterfly-auxiliary-folder/_data`文件夹剪切到`/blog/source`文件夹下。如图所示。

{% endblockquote %}

![blog_data.png](https://i.loli.net/2020/07/27/JFQ7CsyZxtqkKuN.png)

<!-- endtab -->

<!-- tab 第五步 -->

{% blockquote %}

双击`VS Code`快捷键，然后在里面打开文件夹，操作如下

{% endblockquote %}

![operation-5.png](https://i.loli.net/2020/07/11/Ebm2jH3wITAilgB.png)

<!-- endtab -->

<!-- tab 第六步 -->

{% blockquote %}

更改`/blog/_config.yml`文件中的`theme`，将`landscape`改成`butterfly`。操作如下。

{% endblockquote %}

![operation-6.png](https://i.loli.net/2020/07/11/kfVAn7EwQXMhbCJ.png)

<!-- endtab -->

<!-- tab 第七步 -->

{% blockquote %}

到这一步就完事了，在`blog`文件夹下输入下面的命令可以在本地跑了

``` shell 
hexo g

hexo s
```



{% endblockquote %}

<!-- endtab -->

{% endtabs %}

# 自定义一些简单的内容

{%  tabs content-7 %}

> 下面所有内容，都在` /blog/source/_data/butterfly.yml `文件更改

 <!-- tab 首页标题 -->

> 在` /blog `下的` _config.yml` 里面可以改

![_config-yml.png](https://i.loli.net/2020/07/19/iyX2VuzJb3YoA6a.png)

![_config-yml-display.png](https://i.loli.net/2020/07/19/XnEFykpmvc1rxCN.png)

<!-- endtab -->

<!-- tab 文章标签 tags （必选）-->

> 在/blog 下面执行 `hexo new page tags` ，找到对应文件夹下面的` index.md`文件，在下面的文件上加上 `type: "tags"`

![create-tags-categories-1.png](https://i.loli.net/2020/07/19/ph7IvoMS2zaZbKL.png)

<!-- endtab -->

<!-- tab 文章分类 categories （必选）-->

> 在`/blog` 下面执行 `hexo new page categories`  和上面的操作一样，找到`/blog/categories/`文件夹下面的`index.md`文件，在下面的文件上加上 `type: "categories"`。这里个`tags`改成`categories`就行了。
![create-tags-categories-1.png](https://i.loli.net/2020/07/19/ph7IvoMS2zaZbKL.png)

<!-- endtab -->

<!-- tab 侧边栏显示 -->

> `aside`这里可以改公告内容，侧边栏在哪边显示等等

![aside.png](https://i.loli.net/2020/07/19/4xbjFcG6U5KpXiw.png)

<!-- endtab -->

<!-- tab 头像（可选）-->

> avatar:
>
>   img: /img/yinyang.png
>
>   effect: false # 这个是是否旋转你的头像，默认是false
>
> `img` 是图片路径，在` /blog /themes/butterfly/source/img `下。粘贴自己想上传的头像，把这里的路径改一下，就可以了。我建议改成去图床获取头像，减少页面加载时。例如 img: https://i.loli.net/2020/08/15/cAenSihrD4CI3p9.png

![image.png](https://i.loli.net/2020/07/19/fgmXM2hJxWtPGL3.png)

<!-- endtab -->

<!-- tab 首页字显示（可选）-->

> `subtitle`的`sub` 

![subtitle-font.png](https://i.loli.net/2020/07/19/jzIcfuUv5omHKyV.png)

<!-- endtab -->

<!-- tab 首页图片显示（可选）-->

> `defual_top_img` 图片中介绍

![top_img.png](https://i.loli.net/2020/07/19/wTtp4Ccsl7xbeM1.png)
![top_img_display.png](https://i.loli.net/2020/07/19/C3eEWDBO2QtGmvd.png)

<!-- endtab -->

<!-- tab 文章图片（可选）-->

> 搜索`cover`这个是默认的文章封面，第二张图是文章中如何更改封面，第三张图是封面展示

![default_cover_setting.png](https://i.loli.net/2020/07/19/gTQvcMCmfGSPxJp.png)

![change_cover_tags_categories.png](https://i.loli.net/2020/07/19/y1EPilIkM2nLKNv.png)

![image.png](https://i.loli.net/2020/07/19/ReZPKyzm5uviG7D.png)

<!-- endtab -->

<!-- tab 鼠标点击显示（可选）-->

> `ClickShowText` 三选一，我建议是第三个

![click-show-text.png](https://i.loli.net/2020/07/19/GWeNd83w5mfFV4S.png)

![click-show-text-display.png](https://i.loli.net/2020/07/19/XonEGwuMAUWVNRs.png)

<!-- endtab -->

<!-- tab 网页底部显示（可选）-->

`footer_custom_text` 改成你想要展示的内容

![footer_custom_text.png](https://i.loli.net/2020/07/19/EqRdjYe4AF1VLxb.png)

![foot-display.png](https://i.loli.net/2020/07/19/Yr762KzWou3HSOa.png)

<!-- endtab -->

<!-- tab 更多丰富的内容 -->

添加 `QQ` 音乐列表，以及如何获得`音乐 ID`和`音乐列表 ID`。

1. 网页登录`QQ`音乐
2. 到你的歌单中
3. 按`F12`，点到控制台顶部`network`
4. 刷新页面
5. https://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg 这个请求响应里面，`disstid: "7652784085"` 这就是歌单 id，`songlist` 下是该歌单下所有歌曲信息（里面有很多重复的请求，外表光鲜亮丽，，网页版 QQ 音乐已经烂了，很多无用的请求虽然只有几 ms）。
6. 具体使用歌单 ID，[请参考](https://github.com/MoePlayer/hexo-tag-aplayer/blob/master/docs/README-zh_cn.md)

更多设置，[请参考](https://demo.jerryc.me/)

<!-- endtab -->

{% endtabs %}

# 写文章

可以通过两种方式，

1. `hexo new` ''这是一片文章''

2. 直接在`blog/source/_posts`/中创建 `md` 文件，其实就是文本文件，你只要改后缀名就行了

文章头部有以下信息

``` markdown
---
title: 搭建免费博客网站懒人包
date: 2020-07-10 21:51:58
tags: “搭建博客”
categories: "搭建博客"
# 如果hexo g生成文章时报错，请把 Front-matter 也就是这里的内容删了，重新写一遍
# ...等等，还要设置其他具体内容例如该文章头部图片，尾部图片等等，[请参考](https://demo.jerryc.me/posts/dc584b87/)
---
```

# 部署到 Github 上

{% tabs content-11 %}

<!-- tab 第一步 -->

> 同样的，在 `/blog `文件夹下，进行输入命令。通过 `Git bash `来操作，双击桌面的` Git bash`。

```shell
cd Desktop/blog

npm install hexo-deployer-git --save

git config --global user.name "你的 github 名字"

git config --global user.email "你的邮箱"

ssh-keygen -o
# 一直按回车就行了

cat ~/.ssh/id_rsa.pub
# 复制下面内容

```

![deploy-1.png](https://i.loli.net/2020/07/19/NKgE1UqAi4X2fMR.png)

<!-- endtab -->

<!-- tab 第二步 -->

> 到你的` github`下面的` xxxx.github.io repository` 下面，按步骤点击

![deploy-2.png](https://i.loli.net/2020/07/19/raDgmH87OqEFLsy.png)

<!-- endtab -->



<!-- tab 第三步 -->

> 添加 `deploy key`

![deploy-3.png](https://i.loli.net/2020/07/19/dgEbFLUWJCHKDSY.png)

<!-- endtab -->

<!-- tab 第四步 -->

> 更改` /blog `下面的 `_config.yml` 文件。按照图中内容输出

![deploy-4.png](https://i.loli.net/2020/07/19/6QfV4eXZPTl8B2L.png)

<!-- endtab -->

<!-- tab 第五步 -->

> 在` Git bash` 里面输入。执行完下面三个命令，会让你输入用户名和密码，输你自己的 `Github`的用户名和密码

``` shell
hexo clean

hexo g

hexo d
```

![hexo-deploy-5-1.png](https://i.loli.net/2020/07/19/gNoEnxmvDhsIPFd.png)

![hexo-deploy-5-2.png](https://i.loli.net/2020/07/19/UewBXzusHpyE5LY.png)

<!-- endtab -->

<!-- tab 第六步 -->

> 一分钟左右，甚至马上你就可以访问` xxxxx.github.io`  这个` xxxx `是你的用户名

![hexo-deploy-6.png](https://i.loli.net/2020/07/19/QCYZRLMvxtHkX1r.png)

<!-- endtab -->

{% endtabs %}

# 之后部署
## 写一篇文章并部署至 GithubPages （xxxx.github.io）

> 在 `Teminal`  中 `/blog` 文件夹下输入下面命令

``` shell
hexo new "这是一篇文章"

# 如果你改动了除了文章下的文件，我建议你执行一下这个命令
hexo clean

hexo g

hexo d
# 至此搞定
```
> 可以在` hexo g` 之后，执行` hexo s`，来在本地运行，访问 `localhost:4000` 先审视一遍文章。

# 附录

## 推荐的图床

> 超过 `1M` 的图片，我建议[压缩](https://tinyjpg.com/)一下



>  1. [`sm.ms`](sm.sm)这个不需要登陆就可以传图片，但是为了之后的图片找回，最好还是登陆一下，国内也能访问。最好不要把大图片放在`img`文件夹下，加载非常慢。低效。其他图床要么要登陆才能传，要么有很多限制，要么大陆访问不了。
>
>  2. [公益图床。](https://sbimg.cn/)
>
>  3. [路过图床。](https://imgchr.com/)
>  4. 其他什么七牛云之类要实名认证的，我不推荐，操作极其繁琐。

## Markdown编辑器

> 我推荐 `Typora` 。下了腾讯管家的，可以在它的软件管家下载这个软件，或者 `Google`搜官网（我试过了，官网下载超级慢）。
>
> 如果你有更好用的 `MarkDown` 编辑器推荐的话，欢迎留言。
>

## 文章格式建议

> 1. 英文字母与中文空格出一行，或者用 1左边的按键输出的符号，包裹住英文字符。
>2. 每个段落阐明不同意思，`Markdown`编辑器已经默认帮你每个段落隔开一行了。
> 3. 一个`# `号表示一级标题，`## `表示二级标题，以此类推。
>4. 更多[文章格式参考](https://github.com/ruanyf/document-style-guide)
> 5. 更多 `Markdown` 语法的介绍，可以看[这里](https://chrisniael.gitbooks.io/gitbook-documentation/content/format/markdown.html)

## 利用 CDN 和域名加速你的 Github Pages

在`source`文件夹下，新增 `CNAME `文件，填上你的域名。具体操作，参考[这里](https://cyfeng.science/2020/02/02/cloudflare-github-pages/)。我翻了几十篇博客，找到这个适合的。域名购买以及 `CDN `选择，参考那篇文章。可以用免费的域名（不推荐，除非你只是拿来玩一玩的），也可以买 `me` 结尾的域名，具体购买，知乎上有域名购买推荐，例如[这篇](https://www.zhihu.com/question/19551906)

# 参考

> [hexo](https://hexo.io/zh-cn/docs/setup)

> [hexo的butterfly主题](https://demo.jerryc.me/posts/21cfbf15/)

> [npm配置国内镜像资源+淘宝镜像](https://blog.csdn.net/qq_39207948/article/details/79449633)

> [Markdown中文文档](https://markdown-zh.readthedocs.io/en/latest/)

> [盘点国内免费好用的图床](https://zhuanlan.zhihu.com/p/35270383)

