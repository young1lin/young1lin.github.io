---
title: "Youtube 看不了评论"
date: 2021-05-17 00:00
tags: ["other"]
cover: "https://i.loli.net/2021/05/28/A6hTfXYpK15nSCz.png"
categories: "notes"
---

Youtube 看不了评论，一直在转圈圈。

# 简单

清除 Youtube 所有 Cookie，退出谷歌浏览器，再进。

# 进阶

如果还是不行，看看是不是无痕模式下可以看评论，如果可以，把所有插件关了，再重启浏览器。油猴的插件部分有问题。

# 终极

搜索 `重置设置`，重设浏览器，彻底退出谷歌浏览器，再重新登录 Youtube，评论即可看到了。