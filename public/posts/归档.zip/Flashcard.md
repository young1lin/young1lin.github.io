---
title: "仅供本人使用，部分内容是缩写，其他人看不懂的"
date: 2020-09-14 00:00
tags: ["Flashcard"]
categories: "notes"
cover: "https://i.loli.net/2021/05/28/nqF2DvMljTyrQk3.jpg"
---
<style>
    #head {
        width: 100%;
        height: 50px;
        display: flex;
    }

    #head-left {
        width: 30%;
        float: right;
    }
    
    #head-center {
        width: 40%;
        text-align: center;
        font-size: 18px
    }
    
    #head-right {
        width: 30%;
        float: left;
    }
    
    #body {
        width: 100%;
        height: 900px;
        display: flex;
    }
    #body h1{
    	display:none;
    }
    #content-input {
        width: 50%;
        height: 900px;
        padding:0 0 0 0;
        background-color: #fafafa;
    }
    
    #leave-message-textarea {
        width: 100%;
    	height:900px;
        outline: 0;
        border: 1px solid #a0b3d6;
        font-size: 14px;
        overflow-x: hidden;
        overflow-y: auto;
        -webkit-user-modify: read-write-plaintext-only;
        line-height: 24px;
        border-color: rgba(82, 168, 236, 0.8);
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1), 0 0 8px rgba(82, 168, 236, 0.6);
    }
    
    [contentEditable=true]:empty:not(:focus):before {
        content: attr(data-text);
    }
    
    #content-output {
        width: 50%;
        height: 900px;
        overflow: auto;
        background-color: #fafafa;
        padding: 1em;
        border: 1px solid #a0b3d6;
    }
    
    button {
        appearance: button;
        -webkit-writing-mode: horizontal-tb !important;
        text-rendering: auto;
        color: -internal-light-dark(buttontext, rgb(170, 170, 170));
        letter-spacing: normal;
        word-spacing: normal;
        text-transform: none;
        text-indent: 0px;
        text-shadow: none;
        display: inline-block;
        text-align: center;
        align-items: flex-start;
        cursor: default;
        background-color: -internal-light-dark(rgb(239, 239, 239), rgb(74, 74, 74));
        box-sizing: border-box;
        margin: 0em;
        font: 400 13.3333px Arial;
        padding: 1px 6px;
        border-width: 2px;
        border-style: outset;
        border-color: -internal-light-dark(rgb(118, 118, 118), rgb(195, 195, 195));
        border-image: initial;
    }
    
    .btn {
        margin-left: 10px;
        border-radius: 20px;
        padding: 12px 23px;
        color: #fff;
        display: inline-block;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        background: #fff;
        border: 1px solid #dcdfe6;
        text-align: center;
        box-sizing: border-box;
        outline: none;
        margin: 0;
        transition: .1s;
        font-weight: 500;
        font-size: 14px;
    }
    
    .btn:hover {
        color: #409eff;
        border-color: #c6e2ff;
        background-color: #ecf5ff;
    }
    
    .fleft {
        float: left;
    }
    
    .fright {
        float: right;
    }
    
    .bg-blue {
        background-color: #409eff;
        border-color: #409eff;
    }
    
    .bg-gray {
        background-color: #909399;
        border-color: #909399;
    }
    
    .bg-green {
        background-color: #67c23a;
        border-color: #67c23a;
    }
    
    .bg-red {
        background-color: #f56c6c;
        border-color: #f56c6c;
    }
</style>
<script type="text/javascript" async>
    // 所有的 cardId
    let flashCards = [];
    // cardId 和 对应的 内容
    let flashCardContentMap = new Map();
    // 已经掌握的 cards 的 id
    let archiveCards = [];
    // 历史记录 cards
    let historyCards = [];
    // 当执行上一个的操作时，下一个 id 将被缓存起来
    let nextCards = [];
    // 缓存已经递归调用查找过的内容
    let existArchiveCards = [];
    // 获取最小值到最大值之前的整数随机数
    function GetRandomNum(Min, Max) {
        var Range = Max - Min;
        var Rand = Math.random();
        return (Min + Math.round(Rand * Range));
    }

    function getRandomCard(){
    	//let cardId = getRandomCard();
        let randomNum = GetRandomNum(0, flashCards.length - 1);
        let cardId = flashCards[randomNum];
        // 之后实现这个功能
        //cardId = getRandomFlashCard(cardId);
        return cardId;
    }
    // function getRandomFlashCard(cardId) {
    // 	for(let existCard in existArchiveCards){
    // 		if(existCard === cardId){
    // 			getRandomFlashCard();
    // 		}
    // 	}
    //     for(let i=0,len=archiveCards.length;i<len;i++){
    //     	if(archiveCards[i] === cardId && i+1 != len){
    //     		existArchiveCards.push(cardId);
    //     		getRandomFlashCard();
    //     	}else{
    //     		existArchiveCards = [];
    //     		return archiveCards[i];
    //     	}
    //     }
    // }
    /**
     * 根据 cardId 获取 cardContent
     * @param carId H2 标题 名称
     */
    function getRandomFlashCardContent(cardId) {
        if (cardId === null || cardId === "") {
            return "";
        }
        return flashCardContentMap.get(cardId);
    }
    /**
     * 输出内容直输出板
     * @param content 内容
     */
    function outputContent(content) {
        $("#content-output").html("");
        $("#content-output").html(content);
    }
    
    /**
     * 清空输出内容
     */
    function clearOutputArea() {
        $("#content-output").html("");
    }
    /**
    * 获取下个 card 并且赋值
    */
    function getNextCard(){
    	let cardId;
        let currentCardId = getCurrentCardId();
        // 先把当前 id push 到历史记录里面
        if(currentCardId != "" && currentCardId != null && currentCardId != undefined ){
        	// 如果当前值不为空， push 进去
        	historyCards.push(currentCardId);
        }
    	let alreadyNextCard = nextCards.pop();
    	if(alreadyNextCard === null || alreadyNextCard === undefined || alreadyNextCard === ""){
    		cardId = getRandomCard();
    	}else{
    		cardId = alreadyNextCard;
    	}
    	// 这里限制一下历史记录cards
    	historyCards.push(cardId);
        pushTitle(cardId);
    }
    /**
    * 获取上一页内容
    */
    function getPreviousCard(){
    	// 当前 ID 先弹出来
        let currentCardId = historyCards.pop();
        let cardId = historyCards.pop();
        // 再把当前 id 缓存起来
        if(currentCardId != "" && currentCardId != null && currentCardId != undefined && cardId != undefined){
            nextCards.push(currentCardId);
            pushTitle(cardId);
        }else{
        	alert("到头了");
        }
    }
    /**
    * 获取当前 cardId 的值
    */
    function getCurrentCardId(){
    	return $("#cardTitle").html();
    }
    function pushTitle(cardId){
    	$("#cardTitle").html(cardId);
    	$("#content-output").html("");
    }
    /**
    * 各个按钮点击事件绑定
    */
    function btnsOnclickBind(){
    	// btn-show
        $("#btn-show").click(function(event) {
            let cardId = $("#cardTitle").html();
            let content = getRandomFlashCardContent(cardId);
            outputContent(content);
        });
        // btn-hide
        $("#btn-hide").click(function(event) {
        	$("#content-output").html("");
        });
        // btn-mastered
        $("#btn-mastered").click(function(event) {
        	//alert("待完善");
        	console.log("待完善");
        });
        // 理论上这里应该不能弹出
        // btn-previous
        $("#btn-previous").click(function(event) {
            getPreviousCard();
        });
        // btn-next
        $("#btn-next").click(function(event) {
            getNextCard();
        });
        // TODO 待实现btn-output 
        // let content = getRandomFlashCardContent(cardId);
    }
    window.onload = function() {
        $.get("/2020/07/29/Interview", function(data) {
            let dom = $.parseHTML(data);
            var a = $(data).find("h2");
            for (let i = 0; i < a.length; i++) {
                // 给 Flashcard id 赋值
                flashCards.push(a[i].id);
            }
            $("#hhh").append(dom);
            for (let i = 0; i < flashCards.length; i++) {
                if (i + 1 != flashCards.length) {
                    let content = $("#" + flashCards[i]).nextUntil("#" + flashCards[i + 1]);
                    // 如果 h2 标签之间有 h1 标签，那么就是跨区间的，需要重新定位
                    // let h1Content = content.find("h1").prevObject;
                    //if(content.find("h1")){
                    //   let h1Id = content.find("h1").id;
                    //   content = $("#"+flashCards[i]).nextUntil("#"+h1Id);
                    // }
                    flashCardContentMap.set(flashCards[i], content);
                }
            }
            // btn add onclick event ======= start
            // 对各个按钮进行 onclick 事件绑定
            btnsOnclickBind();
            getNextCard();
            // btn add onclick event ======= end;
            $("#leave-message-textarea").html("");
        });
    };
</script>

<!-- head start -->

<div id="head">
    <div id="head-left">
        <button id="btn-show" class="btn bg-blue fright" type="button">
            <span>显示内容</span>
        </button>
        <button id="btn-hide" class="btn bg-gray fright" type="button">
            <span>隐藏内容</span>
        </button>
    </div>
    <div id="head-center">
        <span id="cardTitle"></span>
    </div>
    <div id="head-right">
        <button id="btn-previous" class="btn bg-red fleft" type="button">
            <span>上一个</span>
        </button>
        <button id="btn-next" class="btn bg-green fleft" type="button">
            <span>下一个</span>
        </button>
    </div>
    <!-- <input id="btn-output" type="button" value="导出未掌握内容"> -->
</div>

<!-- head end -->
<!-- body start -->

<div id="body">
    <div id="content-input">
        <div id="leave-message-textarea" contenteditable="true" data-text="自我解答">
        </div>
    </div>
    <div id="content-output" ></div>
</div>
<!-- body end -->

<!-- hidden content -->
<div id="hhh" style="display: none;"></div>



