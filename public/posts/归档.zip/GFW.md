---
title: "什么是 SSR、V2ray、Trojan、Clash，什么是机场？"
date: 2020-10-30 00:00
tags: ["GFW"]
categories: "notes"
cover: "https://i.loli.net/2021/05/28/JRSjTNDHUnsdm7a.jpg"
---

# 前言

如果你可以看 Youtube 视频，我建议你直接看[这个](https://www.youtube.com/watch?v=XKZM_AjCUr0&list=PLqybz7NWybwUgR-S6m78tfd-lV4sBvGFG&index=1)系列，不用看我写的。还有，墙带来的正面效果其实远远大于负面效果，首先如果没有墙的保护，国内的互联网企业，没有一个能成为大企业。大家都有 Gmail 谁用其他邮箱？Google 全家桶完全秒杀国内所有企业，欧洲没有墙，你听过欧洲有哪些互联网巨头吗？不仅是对一些无知的人一些保护，避免受到境外势力例如 大纪元 这种，国内很多人很容易被煽动，成了别人的傀儡。最重要的其实还是保护本土科技企业，留有一定时间追赶 Google 这样的超级大公司。

# 原理

简单介绍原理。这里忽略网络传输层，默认是 TCP/IP，也忽略域名污染等等其他内容。

![科学上网原理简单介绍.png](https://i.loli.net/2021/01/03/vYfNCrmi2Gk5QdW.png)

## 代理

如果你了解过 Nginx 肯定会听到无数的 “反向代理”，而 VPN 就是正向代理。两者最大区别，就是一个不知道最终访问的是哪个服务器，一个是知道要访问哪个，但是需要借个道。

代理代理是一种有转发功能的应用程序，它扮演了位于服务器和客户端“中间人”的角色，接收由客户端发送的请求并转发给服务器，同时也接收服务器返回的响应并转发给客户端。

![HTTP 代理](https://res.weread.qq.com/wrepub/epub_907764_81)

## OSI 七层模型和 SOCKS5

**SOCKS**是一种[网络传输协议](https://zh.m.wikipedia.org/wiki/网络传输协议)，主要用于客户端与外网服务器之间通讯的中间传递。SOCKS是"SOCKet Secure"的[缩写](https://zh.m.wikipedia.org/wiki/缩写)[[注 1\]](https://zh.m.wikipedia.org/zh-hans/SOCKS#cite_note-1)。

当[防火墙](https://zh.m.wikipedia.org/wiki/防火墙_(网络))后的客户端要访问外部的服务器时，就跟SOCKS[代理服务器](https://zh.m.wikipedia.org/wiki/代理服务器)连接。这个代理服务器控制客户端访问外网的资格，允许的话，就将客户端的请求发往外部的服务器。

这个协议最初由David Koblas开发，而后由NEC的Ying-Da Lee将其扩展到SOCKS4。最新协议是SOCKS5，与前一版本相比，增加支持[UDP](https://zh.m.wikipedia.org/wiki/用户数据报协议)、验证，以及[IPv6](https://zh.m.wikipedia.org/wiki/IPv6)。

根据[OSI模型](https://zh.m.wikipedia.org/wiki/OSI模型)，SOCKS是[会话层](https://zh.m.wikipedia.org/wiki/会话层)的协议，位于[表示层](https://zh.m.wikipedia.org/wiki/表示层)与[传输层](https://zh.m.wikipedia.org/wiki/传输层)之间。

![TCP/IP_Protocol.png](https://i.loli.net/2020/10/15/QWDC8PHZRobkSr5.png)

Session 就是会话层，在应用层（Application）下面，所以 SOCKS5 能代理 HTTP 请求，而 HTTP 不能代理 SOCKS5 的内容，**从上往下就是依次加各自的协议头部**。通过传输层（Transport）传到另一台机器上，再以此解头部。所以更低层的协议，更加快速，一般的游戏就是到会话层，你如果搞了只在 HTTP 层代理的工具，不能加速的。

# SSR

SSR 又称酸酸乳，小飞机。客户端是下面这个样子的图标，你应该看图就知道为什么叫小飞机了吧。

**下面是 Wikipedia 的解释**。

**Shadowsocks**（简称**SS**）是一种基于[Socks5](https://zh.wikipedia.org/wiki/SOCKS#SOCK5)代理方式的加密传输协议，也可以指实现这个协议的各种开发包。目前包使用[Python](https://zh.wikipedia.org/wiki/Python)、[C](https://zh.wikipedia.org/wiki/C語言)、[C++](https://zh.wikipedia.org/wiki/C%2B%2B)、[C#](https://zh.wikipedia.org/wiki/C♯)、[Go语言](https://zh.wikipedia.org/wiki/Go语言)、[Rust](https://zh.wikipedia.org/wiki/Rust)等编程语言开发，大部分主要实现（[iOS](https://zh.wikipedia.org/wiki/IOS)平台的除外）采用[Apache许可证](https://zh.wikipedia.org/wiki/Apache许可证)、[GPL](https://zh.wikipedia.org/wiki/GPL)、[MIT许可证](https://zh.wikipedia.org/wiki/MIT許可證)等多种[自由软件](https://zh.wikipedia.org/wiki/自由軟體)许可协议[开放源代码](https://zh.wikipedia.org/wiki/開放原始碼)。Shadowsocks分为服务器端和客户端，在使用之前，需要先将服务器端程序部署到服务器上面，然后通过客户端连接并创建本地代理。

![image.png](https://i.loli.net/2020/11/27/2M5ex4uScQh3nvD.png)

## SSR 服务端

一般是由 Python 写的，启动也比较简单，前人已经帮大家写好很多东西了，按照安装步骤来。只需要简单的配置 + 简单的命令 `systemctl shadowsocks start`这种就能启动客户端了。检查防火墙端口开放，检查服务器厂商端口开放，一般就能用客户端输入些参数直连了。就是正向代理而已。

*这里有个坑，需要修改他的 python 源代码，碰到的时候谷歌/Bing 搜一下就行了。*

## SSR 客户端

这个一般是通过白名单的模式，对你访问的非白名单的网站进行代理。比如 bilibili 这种网站，就不会走代理，当然如果你开启了全局代理，所有的请求都会走代理服务器再去你访问的网站，绕一大圈，所以这个慎重开。

# V2ray

V2Ray 可同时开启多个协议支持，包括[Socks](https://zh.m.wikipedia.org/wiki/Socks)、[HTTP](https://zh.m.wikipedia.org/wiki/HTTP)、[Shadowsocks](https://zh.m.wikipedia.org/wiki/Shadowsocks)、VMess、[Trojan](https://zh.m.wikipedia.org/w/index.php?title=Trojan_(协议)&action=edit&redlink=1)和VLESS等。每个协议可单独设置传输载体，比如[TCP](https://zh.m.wikipedia.org/wiki/TCP)、[mKCP](https://zh.m.wikipedia.org/wiki/MKCP)和[WebSocket](https://zh.m.wikipedia.org/wiki/WebSocket)等。

配置比较麻烦不建议自己搭服务器用。

# Trojan

需要安装 Nginx，伪装成正常网站，需要申请个域名。

一般是有一键安装的脚本，可以直接装 Nginx 和 Trojan，这个会伪装成一个“旅游”网站什么的，你的香港的服务器或者其他能访问的服务器会变成一个网站，直接浏览器访问的话。客户端有很多，ClashX 比较好。但是还是不建议自己买服务器搭，又贵又慢。

# [Clash](https://github.com/Dreamacro/clash)

使用 Go 写的，全平台的，支持多个协议的代理客户端。某些厂商就是根据这个来定制化开发他们自己的客户端，并且能加密。

# 机场

所谓的机场，其实就是多个服务器部署了酸酸乳服务端。你可以列出该列表，可以通过自定义规则，例如超时多少切换下一个节点，是否开启负载均衡。

其实就是避免单点，以免一个服务器被封了 IP 之类的，导致不能科学上网了。

由专门的机构来做这件事，不然你一个个买服务器，太贵了。

一般给你的，是多次 Base64 编码后的一串字符串。

# 软路由

## OpenWrt

用树莓派/不用的电脑安装 OpenWrt 作为绕过封锁的软路由，设置对应的网关，以及机场地址，一样可以翻出去。这个就是个*OpenWrt*是适合于嵌入式设备的一个Linux发行版。

# “能”绕过封锁的路由器

其实还是用到了机场。梅林路由器。

# 永远不会被屏蔽的教学 FQ 地方

Github，如果访问不了，可以访问它的镜像网站，有很多镜像网站。

如果国内把 Github 封了（事实上以前封过一段时间），那真的不用开发了。Gitee 圈子太小了，国内大多是业务开发，基础设施，框架很少。用爱发电这种事，大家都坚持不久的。